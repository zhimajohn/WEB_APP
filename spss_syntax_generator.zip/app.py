from flask import Flask, render_template, request, send_file, redirect, url_for, session
from functools import wraps
import os
from werkzeug.utils import secure_filename
import pandas as pd
from lxml import etree
import re
import logging

logging.basicConfig(
    level=logging.DEBUG,
    format='%(asctime)s - %(levelname)s - %(message)s'
)

app = Flask(__name__)
app.secret_key = 'your-secret-key-here'  # Change this to a secure random key
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Ensure upload folder exists
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Add user credentials (in a real application, use a database)
USERS = {
    'admin': 'your-password-here'  # Change this to your desired password
}

# Login decorator
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

# Add login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        if username in USERS and USERS[username] == password:
            session['logged_in'] = True
            return redirect(url_for('upload_file'))
        else:
            return render_template('login.html', error='Invalid credentials')
    
    return render_template('login.html')

# Add logout route
@app.route('/logout')
def logout():
    session.pop('logged_in', None)
    return redirect(url_for('login'))

# Add all your helper functions here
def Select_1(cut_info):
    try:
        re_Select1 = pd.DataFrame(
            columns=['Question ID', 'Type', 'Question Label', 'Value'])
        re_list = []
        # 添加标题
        re_list.append(cut_info[0][15:])
        # 添加题目类型
        re_list.append(cut_info[2][5:])
        # 添加问题
        try:
            re_list.append(cut_info[0][15:] + ' - ' +
                        cut_info[cut_info.index('[Header 2]:') + 1].replace('<b>', '').replace('</b>', '').replace(
                            '<i>Select one.</i>', '').replace('<br>', ''))
        except:
            re_list.append('')
        header_cnt = 2
        while True:
            if '<br />' in re_list[2]:
                re_list[2] = re_list[2].replace(
                    '<br />', '') + ' ' + cut_info[cut_info.index('[Header 2]:') +
                                                header_cnt]
                header_cnt += 1
            else:
                break
        re_list[2] = re_list[2].replace('<b>', '').replace('</b>', '').replace(
            '<i>Select all that apply.</i>',
            '').replace('<br>', '').replace('<br />',
                                            '').replace('<i>',
                                                        '').replace('</i>', '')
        # 添加选项
        if '[Post-Skips]:' in cut_info:
            end = cut_info.index('[Post-Skips]:')
        else:
            end = len(cut_info)

        start = end - int(cut_info[end - 1].split('\t')[0])
        option_tmp = cut_info[start:end]
        option = '\n'.join(option_tmp).replace('\t', '.')
        re_list.append(option)
        re_Select1.loc[0] = re_list

        return re_Select1
    except Exception as e:
        logging.error(f"Error processing single-choice question: {e}, Data: {cut_info}")
        return pd.DataFrame()

def Select_2(cut_info):
    try:
        re_Select2 = pd.DataFrame(
            columns=['Question ID', 'Type', 'Question Label', 'Value'])
        re_list = []
        # 添加标题
        re_list.append(cut_info[0][15:])
        # 添加题目类型
        re_list.append(cut_info[2][5:])
        # 添加问题
        try:
            re_list.append(cut_info[0][15:] + ' - ' +
                        cut_info[cut_info.index('[Header 2]:') + 1].replace('<b>', '').replace('</b>', '').replace(
                            '<i>Select all that apply.</i>', '').replace('<br>', ''))
        except:
            re_list.append('')
        header_cnt = 2
        while True:
            if '<br />' in re_list[2]:
                re_list[2] = re_list[2].replace(
                    '<br />', '') + ' ' + cut_info[cut_info.index('[Header 2]:') +
                                                header_cnt]
                header_cnt += 1
            else:
                break
        re_list[2] = re_list[2].replace('<b>', '').replace('</b>', '').replace(
            '<i>Select all that apply.</i>',
            '').replace('<br>', '').replace('<br />',
                                            '').replace('<i>',
                                                        '').replace('</i>', '')
        # 添加选项
        if '[Post-Skips]:' in cut_info:
            end = cut_info.index('[Post-Skips]:')
        else:
            end = len(cut_info)
        
        if cut_info[end - 1].split('\t')[0] == '</style>':
            end = cut_info.index('[Footer]:')
        start = end - int(cut_info[end - 1].split('\t')[0])
        option = cut_info[start:end]
        for i in range(len(option)):
            re_add = []
            if i == 0:
                re_add.append(re_list[0] + '_' + str(i + 1))
                re_add.append(re_list[1])
                re_add.append(re_list[2] + ' ' + option[0].split('\t')[1])
                re_add.append('0=NO 1=YES')
            else:
                re_add.append(re_list[0] + '_' + str(i + 1))
                re_add.append(re_list[1])
                re_add.append(option[i].split('\t')[1].replace('[Exclusive]', ''))
                re_add.append('0=NO 1=YES')
            re_Select2.loc[i] = re_add
        return re_Select2
    except Exception as e:
        logging.error(f"Error processing multiple-choice question: {e}, Data: {cut_info}")
        return pd.DataFrame()

def Select_3(cut_info):
    pass

def Free_format(cut_info):
    re_free = pd.DataFrame(
        columns=['Question ID', 'Type', 'Question Label', 'Value'])
    re_list = []
    # 添加标题
    re_list.append(cut_info[0][15:])
    # 添加题目类型
    re_list.append(cut_info[2][5:])
    # 添加问题
    try:
        re_list.append(cut_info[0][15:] + ' - ' +
                       cut_info[cut_info.index('[Header 2]:') + 1].replace('<b>', '').replace('</b>', '').replace(
                           '<i>Select all that apply.</i>', '').replace('<br>', ''))
    except:
        re_list.append('')
    header_cnt = 2
    while True:
        if '<br />' in re_list[2]:
            try:
                re_list[2] = re_list[2].replace(
                    '<br />', '') + ' ' + cut_info[cut_info.index('[Header 2]:') +
                                                   header_cnt]
            except:
                print('please Check：', re_list[0])
                break
            header_cnt += 1
        else:
            break
    re_list[2] = re_list[2].replace('<b>', '').replace('</b>', '').replace(
        '<i>Select all that apply.</i>',
        '').replace('<br>', '').replace('<br />',
                                        '').replace('<i>',
                                                    '').replace('</i>', '')
    re_list.append('')
    re_free.loc[0] = re_list
    var = 1
    while True:
        new_list = []
        try:
            question_pos = cut_info.index('[Variable %d]:' % var) + 1
            new_list.append(cut_info[question_pos][5:].strip())
            new_list.append(cut_info[question_pos + 1][5:].strip())
            new_list.append('')
            new_list.append('')
            re_free.loc[new_list[0]] = new_list
        except:
            break
        var += 1
    return re_free

def Grid(cut_info):
    re_Select2 = pd.DataFrame(
        columns=['Question ID', 'Type', 'Question Label', 'Value'])
    re_list = []
    # 添加提目标号
    re_list.append(cut_info[0][15:])
    # 添加题目类型
    re_list.append(cut_info[2][5:])
    # 添加问题
    re_list.append(cut_info[0][15:] + ' - ' +
                   cut_info[cut_info.index('[Header 2]:') + 1])
    header_cnt = 2

    while True:
        if '<br />' in re_list[2]:
            re_list[2] = re_list[2].replace(
                '<br />', '') + ' ' + cut_info[cut_info.index('[Header 2]:') +
                                               header_cnt]
            header_cnt += 1
        else:
            break
    re_list[2] = re_list[2].replace('<b>', '').replace('</b>', '').replace(
        '<i>Select all that apply.</i>',
        '').replace('<br>', '').replace('<br />',
                                        '').replace('<i>',
                                                    '').replace('</i>', '')
    re_list.append(0)

    # 筛选col（顺序在后）
    try:
        col_index = cut_info.index('[Row 1]:') - 1
    except:
        col_index = cut_info.index('[Column 1]:') - 1
    if cut_info[col_index] == 'Total':
        col_index -= 1
    col_start_index = col_index - int(cut_info[col_index].split('\t')[0])
    col_list = cut_info[col_start_index + 1:col_index + 1]
    
    # 筛选row（顺序在前）
    # 定位Grid单/多选
    try:
        grid_type = cut_info.index('[Row 1]:') + 1
    except:
        grid_type = cut_info.index('[Column 1]:') + 1

    # 对于表格-单选题进行操作
    if cut_info[grid_type] == 'Type: Select (Radio Button)':
        # Process radio button grid
        row_index = cut_info.index('[Column List]:') - 1
        while row_index > 0:
            ind = cut_info[row_index].split('\t')
            if ind[0] == cut_info[row_index]:
                row_index -= 1
            else:
                for i in range(row_index - int(ind[0]) + 1, row_index + 1):
                    add_list = []
                    row_list = cut_info[i].split('\t')
                    if '<table class="trow">' in row_list[0]:
                        html = etree.HTML(row_list[0])
                        row_list[0] = html.xpath('//table/tr/td[2]/@title')[0].split('<p>')[0].replace('<i>', '')
                    row_list[1] = row_list[1].replace('<b>', '').replace('</b>', '').replace('<br>', '').replace('<br/>', '').replace('<br />', '').replace('<i>', '').replace('</i>', '')
                    add_list.append(re_list[0] + '_r' + row_list[0])
                    add_list.append(re_list[1])
                    if row_list[0] == '1':
                        if len(row_list) > 1:
                            add_list.append(re_list[2] + row_list[1])
                        else:
                            add_list.append(re_list[2] + row_list[0])
                        add_list.append('\n'.join(col_list).replace('\t', '.'))
                    else:
                        if len(row_list) > 1:
                            add_list.append(row_list[1])
                        else:
                            add_list.append(row_list[0])
                        add_list.append('\n'.join(col_list).replace('\t', '.'))
                    re_Select2.loc[str(row_index) + str(i) + 'test'] = add_list
                break
    else:
        # Process other grid types
        row_end_index = cut_info.index('[Column List]:') - 1
        try:
            row_end = int(cut_info[row_end_index].split('\t')[0])
        except:
            row_end_index -= 1
        if 'Total' in cut_info[row_end_index]:
            row_end_index -= 1
        if 'S9li' in cut_info[row_end_index]:
            row_end_index -= 3
        row_end = int(cut_info[row_end_index].split('\t')[0])
        row_start = row_end_index - row_end

        try:
            col_end_index = cut_info.index('[Row 1]:') - 1
        except:
            col_end_index = cut_info.index('[Column 1]:') - 1

        if cut_info[col_end_index] == 'Total':
            col_end_index -= 1
        col_start_index = col_end_index - int(cut_info[col_end_index].split('\t')[0])
        
        c = 1
        for col in range(col_start_index + 1, col_end_index + 1):
            r = 1
            for row in range(row_start + 1, row_end_index + 1):
                add_list = []
                add_list.append(re_list[0] + '_r' + str(r) + '_c' + str(c))
                add_list.append(re_list[1])

                if '<table class="trow">' in cut_info[row]:
                    html = etree.HTML(cut_info[row])
                    try:
                        cut_info[row] = html.xpath('//table/tr/td[2]/@title')[0].split('<p>')[0].replace('<i>', '')
                    except:
                        cut_info[row] = html.xpath('//span/text()')[0]
                else:
                    try:
                        cut_info[row] = cut_info[row].split('\t')[1]
                    except:
                        pass
                cut_info[row] = cut_info[row].replace('<b>', '').replace('</b>', '').replace('<br>', '').replace('<br/>', '').replace('<br />', '').replace('<i>', '').replace('</i>', '').replace('[Exclusive]', '')

                if '<table class="trow">' in cut_info[col]:
                    html = etree.HTML(cut_info[col])
                    try:
                        cut_info[col] = html.xpath('//table/tr/td[2]/@title')[0].split('<p>')[0].replace('<i>', '')
                    except:
                        cut_info[col] = html.xpath('//span/text()')[0]
                else:
                    try:
                        cut_info[col] = cut_info[col].split('\t')[1]
                    except:
                        pass
                cut_info[col] = cut_info[col].replace('<b>', '').replace('</b>', '').replace('<br>', '').replace('<br/>', '').replace('<br />', '').replace('<i>', '').replace('</i>', '').replace('[Exclusive]', '')

                if c == 1 and r == 1:
                    add_list.append(re_list[2] + ' ' + cut_info[row] + ' - ' + cut_info[col])
                else:
                    add_list.append(cut_info[row] + ' - ' + cut_info[col])
                add_list.append('0=No 1=Yes')
                re_Select2.loc[str(col) + str(row)] = add_list
                r += 1
            c += 1
    return re_Select2

def clean_(x, clean_list):
    for i in clean_list:
        i = i.strip('\n')
        if i in x:
            x = x.replace(i, '')
    S = re.compile(r'\<(.*?)\>', re.S)
    return re.sub(S, '', x).strip()

def type_change(x):
    if x.strip() == 'Select (Radio Button)':
        return 'Single'
    elif x.strip() == 'Select (Check Box)':
        return 'Multi'
    else:
        return x.strip()

def Data_map(path, clean_txt):
    try:
        # 构造结果存储DF
        result = pd.DataFrame(columns=['Question ID', 'Type', 'Question Label', 'Value'])
        
        logging.debug(f"Opening file: {path}")
        # 读取文件
        label_txt = open(path, encoding='utf-8')
        # 按行读取
        txt = label_txt.readlines()
        
        logging.debug(f"Number of lines read: {len(txt)}")
        
        # 获取清洗后的文件内容
        txt_clean = []
        for i in txt:
            res = i.strip('\n\t')
            if res != '':
                txt_clean.append(res)
                
        logging.debug(f"Number of non-empty lines: {len(txt_clean)}")
        
        Q_list_index_a = txt_clean.index('Question List')
        Q_list_index_b = txt_clean.index('Data Field Usage')
        
        logging.debug(f"Question List found at index: {Q_list_index_a}")
        logging.debug(f"Data Field Usage found at index: {Q_list_index_b}")
        
        # 得到题目类型列表
        Q_list = txt_clean[Q_list_index_a + 4: Q_list_index_b - 4]
        Q_list_info = []
        
        # 将文档分块，每个题目一块
        for i in Q_list:
            Q_name = i.split()[0]
            index_a = txt_clean.index('Question Name: ' + Q_name)
            index_b = txt_clean[index_a:].index(
                '----------------------------------<PAGE BREAK>----------------------------------'
            )
            Q_list_info.append(txt_clean[index_a:index_a + index_b])

        # Process each question
        for i in Q_list_info:
            if i[2] == 'Type: Select (Radio Button)' or i[2] == 'Type: Select (Dropdown)':
                r = Select_1(i)
                result = pd.concat([result, r])
            elif i[2] == 'Type: Select (Check Box)':
                r = Select_2(i)
                result = pd.concat([result, r])
            elif i[2] == 'Type: Grid':
                r = Grid(i)
                result = pd.concat([result, r])
            else:
                r = Free_format(i)
                result = pd.concat([result, r])

        result.reindex()
        clean_t = open(clean_txt, encoding='utf-8').readlines()

        result['Question ID'] = result['Question ID'].apply(clean_, clean_list=clean_t)
        result['Question Label'] = result['Question Label'].apply(clean_, clean_list=clean_t)
        result['Type'] = result['Type'].apply(type_change)
        result['Value'] = result['Value'].apply(clean_, clean_list=clean_t)
        
        logging.debug(f"Processed {len(result)} questions")
        return result
        
    except Exception as e:
        logging.error(f"Error in Data_map: {str(e)}")
        return None

def single_trans(original_string):
    modified_string = re.sub(r'(\d+)\.', r'\1"', original_string)
    modified_string = modified_string.replace("\n", '''"\n''')
    modified_string = modified_string+'''".'''
    return modified_string

def generate_spss_syntax(row):
    syntax = []
    if row[1] == 'Single':
        syntax.append(f'\nVARIABLE LABELS {row[0]} "{row[2]}".')
        syntax.append(f'VALUE LABELS {row[0]}')
        syntax.append(f'{single_trans(row[3])}\n')
    elif row[1] == 'Multi':
        syntax.append(f'VARIABLE LABELS {row[0]} "{row[2]}".')
    elif row[1] == 'Value':
        syntax.append(f'\nVARIABLE LABELS {row[0]} "{row[2]}".\n')
    elif row[1] == 'Grid' and row[3] == "0=No 1=Yes":
        syntax.append(f'VARIABLE LABELS {row[0]} "{row[2]}".\n')
    elif row[1] == 'Grid':
        syntax.append(f'VARIABLE LABELS {row[0]} "{row[2]}".')
        syntax.append(f'VALUE LABELS {row[0]}')
        syntax.append(f'{single_trans(row[3])}\n')
    elif row[1] == 'Free Format':
        syntax.append(f'VARIABLE LABELS {row[0]} "{row[2]}".')
    elif row[1] == 'Select (Dropdown)':
        syntax.append(f'\nVARIABLE LABELS {row[0]} "{row[2]}".')
        syntax.append(f'VALUE LABELS {row[0]}')
        syntax.append(f'{single_trans(row[3])}\n')
    return '\n'.join(syntax)

def process_txt_file(file_path):
    try:
        # Create a default clean.txt in the uploads folder if it doesn't exist
        clean_txt_path = os.path.join(app.config['UPLOAD_FOLDER'], 'clean.txt')
        if not os.path.exists(clean_txt_path):
            with open(clean_txt_path, 'w', encoding='utf-8') as f:
                f.write('')  # Add default cleaning rules if needed
        
        # Process the file using your existing logic
        result_df = Data_map(file_path, clean_txt_path)
        
        # Add error checking for result_df
        if result_df is None or result_df.empty:
            error_msg = "Failed to process the file: No data was extracted"
            logging.error(error_msg)
            return error_msg
            
        # Generate SPSS syntax
        all_syntax = []
        for _, row in result_df.iterrows():
            syntax = generate_spss_syntax(row)
            if syntax:  # Only add non-empty syntax
                all_syntax.append(syntax)
        
        if not all_syntax:
            return "No SPSS syntax was generated from the file"
            
        return '\n'.join(all_syntax)
        
    except Exception as e:
        error_msg = f"Error processing file: {str(e)}"
        logging.error(error_msg)
        return error_msg

@app.route('/', methods=['GET', 'POST'])
@login_required
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            return 'No file uploaded', 400
        
        file = request.files['file']
        if file.filename == '':
            return 'No file selected', 400
        
        if file and file.filename.endswith('.txt'):
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            
            # Process the file and generate SPSS syntax
            spss_syntax = process_txt_file(filepath)
            
            # Clean up the uploaded file
            os.remove(filepath)
            
            return render_template('result.html', syntax=spss_syntax)
        
        return 'Invalid file type. Please upload a .txt file.', 400
    
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True) 